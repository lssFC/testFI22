package com.fc.client.TestCases;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.fc.client.ParentClass.BaseInit;
import com.fc.client.ParentClass.Constants;
import com.fc.client.Utility.Util;

public class Sample_SmokeTestCases extends BaseInit {

	@BeforeTest(alwaysRun = true)
	public void testCheckTestCase() throws IOException {
		//Startup method to launch browser
		StartUp();
		System.out.println("Execution mode of " + this.getClass().getSimpleName() + " Test Case is set to Yes");
	}

	@AfterTest(alwaysRun = true)
	public void tearDown() throws Exception {
		//Util.logout();
		driver.quit();

	}

	/***
	 * Author: Falgun Contractor This test case is for Creating default user set
	 * 1. Launch browser and Register one default user 2. Create default
	 * Category for this user
	 * 
	 * @throws Exception
	 **/
	@Test(priority = 1)
	public void CreateDefaultUsers()  {
		System.out.println("========================================");
		System.out.println("Start CreateDefaultUsers");
		System.out.println("========================================");
		try {
			Util.Registration(Constants.USERNAME);
			if (Util.isElementExistsBy(driver, Constants.Login_alertMessage)){
				String alertMessage = Util.GetTextBy(driver, Constants.Login_alertMessage);
				Assert.assertEquals("unknown login or wrong password", alertMessage, "Error: Invalid alert message..");
			}else{
			
			Util.CreateCategory(Constants.DefaultCategory);
			System.out.println("Default user/category is created...");
			Util.ClickElementBy(driver, Constants.Link_logout);
			
			}
		} catch (Exception e) {
		
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End CreateDefaultUsers");
		System.out.println("========================================");

	}
	/***
	 * Author: Falgun Contractor This test case is for Registering a new User 1.
	 * Launch browser and Click on registration link on homepage 2. Verify
	 * navigation and register new user valid data 3. Verify navigation after
	 * successful registration of new user 4. Verify Username after successful
	 * registration of new user 5. Perform logout operation 6. Verify navigation
	 * after log out 7. Now re-register with same username and verify
	 **/
	@Test(priority = 2)
	public void Test_RegisterSameUser() {
		System.out.println("========================================");
		System.out.println("Start Test_RegisterSameUser");
		System.out.println("========================================");
		try {
			String ExpectedNewUser = Constants.RegisterSameUSERNAME;
			Util.Registration(ExpectedNewUser);
			System.out.println("New user is registred successfully....");
			
			System.out.println("Checking if - New registered username is displayed...");
			String actualUserName = Util.GetTextBy(driver, Constants.Link_editaccount);
			System.out.println("Actual Username Displayed: " + actualUserName);
			System.out.println("Expected Username Displayed: " + ExpectedNewUser);
			
			Assert.assertEquals(ExpectedNewUser, actualUserName, "Error: New user registration fails..");
			System.out.println("New user registered successfully...");
			
			System.out.println("Verifying New registred user logout...");		
			Util.ClickElementBy(driver, Constants.Link_logout);					
			Assert.assertEquals(true, Util.isElementExistsBy(driver, Constants.Txt_Username),
					"Error: New registred user logout fails..");
			System.out.println("New registred user logout successfully...");
			
			System.out.println("Registring with same username again...");
			Util.Registration(ExpectedNewUser);
			if(Util.isElementExistsBy(driver, Constants.Link_editaccount)){
				System.out.println("Registring with same username again is working ...FAIL");
				Assert.fail("Error: New registred user can be register again..");
			}else{
				System.out.println("Unable to register with same username ...PASS");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End Test_RegisterSameUser");
		System.out.println("========================================");

	}
	/***
	 * Author: Falgun Contractor This test case is for Registering a new User 1.
	 * Launch browser and Click on registration link on homepage 2. Verify
	 * navigation and register new user valid data 3. Verify navigation after
	 * successful registration of new user 4. Verify Username after successful
	 * registration of new user 5. Perform logout operation 6. Verify navigation
	 * after log out
	 **/
	@Test(priority = 2)
	public void RegisterNewUser()  {
		System.out.println("========================================");
		System.out.println("Start RegisterNewUser");
		System.out.println("========================================");
		try {
			String ExpectedNewUser = Constants.RegisterUSERNAME;
			Util.Registration(ExpectedNewUser);
			System.out.println("New user is registred successfully....");
			
			
			String actualUserName = Util.GetTextBy(driver, Constants.Link_editaccount);
			System.out.println("Actual Username Displayed: " + actualUserName);
			System.out.println("Expected Username Displayed: " + ExpectedNewUser);
			Assert.assertEquals(ExpectedNewUser, actualUserName, "Error: New user registration fails..");
			System.out.println("New registered username id displayed...");
			
			
			System.out.println("Verifying New registred user logout...");
			Util.ClickElementBy(driver, Constants.Link_logout);
			
			Assert.assertEquals(true, Util.isElementExistsBy(driver, Constants.Txt_Username),
					"Error: New registred user logout fails..");
			System.out.println("New registred user logout successfully...");
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End RegisterNewUser");
		System.out.println("========================================");

	}

	@Test(priority = 2)
	public void LoginUser() {
		System.out.println("========================================");
		System.out.println("Start LoginUser");
		System.out.println("========================================");
		try {
			String ExpectedNewUser = Constants.USERNAME;

			Util.login(ExpectedNewUser, Constants.PASSWORD);

			String actualUserName = Util.GetTextBy(driver, Constants.Link_editaccount);
			System.out.println("Actual Username Displayed: " + actualUserName);
			System.out.println("Expected Username Displayed: " + ExpectedNewUser);
			Assert.assertEquals(actualUserName, ExpectedNewUser, "Error: Login username mismatch.");
			System.out.println("User Logs in successfully...");

			String actualPageName = Util.GetTextBy(driver, Constants.Header_ListExpenses);
			System.out.println("Actual Username Displayed: " + actualPageName);
			System.out.println("Expected Username Displayed:List Expenses: ");
			Assert.assertEquals(actualPageName, "List Expenses:", "Error: Login user redirected on diffrent page..");

			Util.ClickElementBy(driver, Constants.Link_logout);
			Assert.assertEquals(true, Util.isElementExistsBy(driver, Constants.Txt_Username),
					"Error: New registred user logout fails..");
			System.out.println("Use logout successfully...");
		} catch (Exception e) {
			
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End LoginUser");
		System.out.println("========================================");

	}

	/***
	 * Author: Falgun Contractor This test case is for Adding a new Expense 1.
	 * Launch browser and log in with default user 2. Check user is on List
	 * expenses page 3. Click on Add expense Link and verify navigation 4.
	 * Create new expense by adding valid data 5. Check user is on List expenses
	 * page 6. Verify correct data is displayed in table
	 * 
	 * @throws Exception
	 **/

	@Test(priority = 2)
	public void AddExpenses()  {
		System.out.println("========================================");
		System.out.println("Start AddExpenses");
		System.out.println("========================================");
		try {

			Util.login(Constants.USERNAME, Constants.PASSWORD);
			String header = Util.GetTextBy(driver, Constants.Header_ListExpenses);
			Assert.assertEquals("List Expenses:", header, "Error: Unable to navigate to List Expenses page..");

			String ex_Date = "12.10.17";
			String ex_Category = Constants.DefaultCategory;
			String _Amount = "3333";
			String exp_Amount = "3.333,00 �";
			String exp_Reason = "testexpensereason";
			
			Util.AddExpense("12", "10", "2017", ex_Category, _Amount, exp_Reason);
			System.out.println("New Expense is created successfully....");
			
			System.out.println("Verifiying ListExpenses page after Expense is created....");
			header = Util.GetTextBy(driver, Constants.Header_ListExpenses);
			Assert.assertEquals("List Expenses:", header, "Error: Unable to navigate to List Expenses page..");
			System.out.println("Verified ListExpenses page after Expense is created....");
			
			
			System.out.println("Verifiying Expense data on Table..");
			WebElement wb_table = driver.findElement(By.className("table"));
			List<WebElement> List_RowsName = wb_table.findElements(By.tagName("tbody"));
			boolean bFlag = false;

			for (WebElement RowName : List_RowsName) {
				List<WebElement> List_Child_RowName = RowName.findElements(By.tagName("tr"));
		
				for (WebElement individualCell : List_Child_RowName) {

					List<WebElement> List_CellData = individualCell.findElements(By.tagName("td"));
					WebElement wb_date = List_CellData.get(0);

					if (wb_date.getText().equalsIgnoreCase(ex_Date)) {
						Assert.assertEquals(wb_date.getText(), ex_Date, "Error: Expenses Date mismatch..");
						System.out.println("Expense Date on Table..PASS");
						WebElement wb_category = List_CellData.get(1);
						if (wb_category.getText().equalsIgnoreCase(ex_Category)) {
							WebElement wb_amount = List_CellData.get(2);
							Assert.assertEquals(wb_category.getText(), ex_Category,
									"Error: Expenses Category mismatch..");
							System.out.println("Expense Category on Table..PASS");
							if (wb_amount.getText().equalsIgnoreCase(exp_Amount)) {
								Assert.assertEquals(wb_amount.getText(), exp_Amount,
										"Error: Expenses Amount mismatch..");
								System.out.println("Expense Amount on Table..PASS");
								WebElement wb_reason = List_CellData.get(3);

								if (wb_reason.getText().equalsIgnoreCase(exp_Reason)) {
									Assert.assertEquals(wb_reason.getText().toLowerCase(), exp_Reason,
											"Error: Expenses Reason mismatch..");
									System.out.println("Expense Reason on Table..PASS");
									bFlag = true;

									break;
								}
							}
						}
					}
				}
				if (bFlag) {
					break;
				}
			}

			Assert.assertEquals(bFlag, true, "Error: Expense is not created successfully..");
			System.out.println("New Expense id creaed and verified successfully....");
		} catch (Exception e) {
			
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End AddExpenses");
		System.out.println("========================================");

	}

	/***
	 * Author: Falgun Contractor This test case is for Adding a new category 1.
	 * Launch browser and log in with default user 2. Click on List Category
	 * Link and verify navigation 3. Click on Add Category Button and Add
	 * category navigation 4. Verify Category is created and correct details is
	 * displayed on list category page
	 * 
	 * @throws Exception
	 **/
	@Test(priority = 2)
	public void AddCategory()  {
		System.out.println("========================================");
		System.out.println("Start AddCategory");
		System.out.println("========================================");
		try {

			Util.login(Constants.USERNAME, Constants.PASSWORD);
			System.out.println("Clicking on List category page...");
			Util.ClickElementBy(driver, Constants.Link_ListCategory);

			String actualPageName = Util.GetTextBy(driver, Constants.Header_ListCategory);
			System.out.println("actualPageName Displayed: " + actualPageName);
			System.out.println("Expected PageName Displayed: List Categories");
			Assert.assertEquals(actualPageName, "List Categories", "Error: List Categories Pagename mismatch.");

			Util.ClickElementBy(driver, Constants.Btn_AddCategory);
			actualPageName = Util.GetTextBy(driver, Constants.Header_AddCategory);
			System.out.println("actualPageName Displayed: " + actualPageName);
			System.out.println("Expected PageName Displayed: Add Category");
			Assert.assertEquals(actualPageName, "Add Category", "Error: Add Categories Pagename mismatch.");

			System.out.println("Creating the new category...");
			String ExpectedCategory = Constants.DefaultCategory;
			Util.Element_EnterText(Constants.Txt_CategoryName, ExpectedCategory);
			Util.ClickElementBy(driver, Constants.Btn_Submit);

			boolean flagCategoryPresent = Util.CheckCategoryPresent(ExpectedCategory);
			Assert.assertEquals(flagCategoryPresent, true, "Error: Category is created successfully...");

		} catch (Exception e) {
			
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End AddCategory");
		System.out.println("========================================");

	}

	/**
	 * Author: Falgun Contractor This test case is for Removing a category 1.
	 * Launch browser and login with default user 2. Create new Category by
	 * adding valid data 3. Verify correct data is displayed in table at List
	 * category page 4. Try to remove this recently created Category 5. Check
	 * Delete category alert details 6. On delete category alert click - OK
	 * button 7. Verify category is deleted
	 * 
	 * @throws Exception
	 ***/
	@Test(priority = 4)
	public void RemoveCategory()  {
		System.out.println("========================================");
		System.out.println("Start RemoveCategory");
		System.out.println("========================================");
		try {

			Util.login(Constants.USERNAME, Constants.PASSWORD);

			String exp_FirstCategory = "RemoveCategoryName";
			Util.CreateCategory(exp_FirstCategory);
			System.out.println("Creating category:."+exp_FirstCategory);
						
			System.out.println("Verifying the category on List category page....");
			WebElement wb_table = driver.findElement(By.className("table"));
			List<WebElement> List_parent_CategoryName = wb_table.findElements(By.tagName("tr"));
			boolean bFlag = false;
			boolean deleteFlag = false;
			for (WebElement categoryName : List_parent_CategoryName) {
				List<WebElement> List_Child_CategoryName = categoryName.findElements(By.tagName("td"));
				for (WebElement category_Name : List_Child_CategoryName) {
					String Actual_categoryName = category_Name.getText();
					if (Actual_categoryName.equalsIgnoreCase(exp_FirstCategory)) {
						System.out.println(Actual_categoryName + "  - Category is created successfully...");
						Assert.assertEquals(Actual_categoryName, exp_FirstCategory,
								"Error: Category name is different..");
						bFlag = true;

						if (bFlag) {
							WebElement CheckDeleteButton = List_Child_CategoryName.get(1);
							List<WebElement> List_Delete_Button = CheckDeleteButton.findElements(By.tagName("a"));
							WebElement wb_DeleteButton = List_Delete_Button.get(1);
							System.out.println("Clcking on Delete category button:."+exp_FirstCategory);
							wb_DeleteButton.click();
							deleteFlag = true;
							break;
						}
					}
					break;
				}

				if (deleteFlag) {
					break;
				}
			}
			System.out.println("Checking Delete category Alert...");
			if (deleteFlag) {
				Alert alert = driver.switchTo().alert();

				String alertText = alert.getText();
				String AlertTitle = "Attention: Unrecoverable Delete Action";
				String AlertCategory = exp_FirstCategory;
				String AlertMessage = "Do you really want to delete:";

				boolean Check_AlertTitle = alertText.toLowerCase().contains(AlertTitle.toLowerCase());
				boolean Check_AlertMessage = alertText.toLowerCase().contains(AlertMessage.toLowerCase());
				boolean Check_AlertCategory = alertText.toLowerCase().contains(AlertCategory.toLowerCase());
				Assert.assertEquals(Check_AlertTitle, true, "Error: Delete category -Alert title is mismatched..");
				Assert.assertEquals(Check_AlertMessage, true, "Error: Delete category Alert -Message is mismatched..");
				Assert.assertEquals(Check_AlertCategory, true,
						"Error: Delete category Alert -Category name is mismatched..");
				System.out.println("Delete Category alert is created and verified successfully...");

				alert.accept();
				System.out.println("Acceptiong Delete Category alert...");
			}
			System.out.println("- Verifying category on List Category page...");
			boolean flagCategoryRemoved = Util.CheckCategoryPresent(exp_FirstCategory);
			System.out.println("category  is present in list -" + flagCategoryRemoved);
			Assert.assertEquals(flagCategoryRemoved, false, "Error: Delete Category is not working..");

		} catch (Exception e) {
			
			e.printStackTrace();
			Assert.fail();
		}
		System.out.println("========================================");
		System.out.println("End RemoveCategory");
		System.out.println("========================================");

	}

	/****
	 * Author: Falgun Contractor This test case is for Check cancel button
	 * operation while deleting category 1. Launch browser and log in with
	 * default user 2. Create new Category by adding valid data 3. Verify
	 * correct data is displayed in table at List category page 4. Try to remove
	 * this recently created Category 5. Check Delete category alert details 6.
	 * On delete category alert click - Cancel button 7. Verify category is not
	 * deleted
	 * 
	 * @throws Exception
	 ***/

	@Test(priority = 2)
	public void cancel_RemoveCategory() {
		System.out.println("========================================");
	System.out.println("Start cancel_RemoveCategory");
	System.out.println("========================================");
	try {

		Util.login(Constants.USERNAME, Constants.PASSWORD);

		String exp_FirstCategory = "Cancel_DeleteCategory";
		Util.CreateCategory(exp_FirstCategory);
		System.out.println("Creating category:."+exp_FirstCategory);
		
		
		System.out.println("Verifying the category on List category page....");
		WebElement wb_table = driver.findElement(By.className("table"));
		List<WebElement> List_parent_CategoryName = wb_table.findElements(By.tagName("tr"));
		boolean bFlag = false;
		boolean deleteFlag = false;
		for (WebElement categoryName : List_parent_CategoryName) {
			List<WebElement> List_Child_CategoryName = categoryName.findElements(By.tagName("td"));
			for (WebElement category_Name : List_Child_CategoryName) {
				String Actual_categoryName = category_Name.getText();
				if (Actual_categoryName.equalsIgnoreCase(exp_FirstCategory)) {
					System.out.println(Actual_categoryName + "  - Category is created successfully...");
					Assert.assertEquals(Actual_categoryName, exp_FirstCategory,
							"Error: Category name is different..");
					bFlag = true;

					if (bFlag) {
						WebElement CheckDeleteButton = List_Child_CategoryName.get(1);
						List<WebElement> List_Delete_Button = CheckDeleteButton.findElements(By.tagName("a"));
						WebElement wb_DeleteButton = List_Delete_Button.get(1);
						System.out.println("Clcking on Delete category button:."+exp_FirstCategory);
						wb_DeleteButton.click();
						deleteFlag = true;
						break;
					}
				}
				break;
			}

			if (deleteFlag) {
				break;
			}
		}
		System.out.println("Checking Delete category Alert...");
		if (deleteFlag) {
			Alert alert = driver.switchTo().alert();

			String alertText = alert.getText();
			String AlertTitle = "Attention: Unrecoverable Delete Action";
			String AlertCategory = exp_FirstCategory;
			String AlertMessage = "Do you really want to delete:";

			boolean Check_AlertTitle = alertText.toLowerCase().contains(AlertTitle.toLowerCase());
			boolean Check_AlertMessage = alertText.toLowerCase().contains(AlertMessage.toLowerCase());
			boolean Check_AlertCategory = alertText.toLowerCase().contains(AlertCategory.toLowerCase());
			Assert.assertEquals(Check_AlertTitle, true, "Error: Delete category -Alert title is mismatched..");
			Assert.assertEquals(Check_AlertMessage, true, "Error: Delete category Alert -Message is mismatched..");
			Assert.assertEquals(Check_AlertCategory, true,
					"Error: Delete category Alert -Category name is mismatched..");
			System.out.println("Delete Category alert is created and verified successfully...");

			alert.dismiss();
			System.out.println("Canceling Delete Category alert...");
		}
		System.out.println("- Verifying category on List Category page...");
		boolean flagCategoryRemoved = Util.CheckCategoryPresent(exp_FirstCategory);
		System.out.println("category  is present in list -" + flagCategoryRemoved);
		Assert.assertEquals(flagCategoryRemoved, true, "Error: Canceling Delete Category is not working..");
		System.out.println("Canceling Delete Category is working..");
	} catch (Exception e) {
		
		e.printStackTrace();
		Assert.fail();
	}
	System.out.println("========================================");
	System.out.println("End cancel_RemoveCategory");
	System.out.println("========================================");
}
}
