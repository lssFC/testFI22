package com.fc.client.TestCases;

import java.io.IOException;
import org.testng.annotations.BeforeSuite;
import com.fc.client.ParentClass.BaseInit;

public class BaseInitUserSide extends BaseInit {

	@BeforeSuite
	public void testCheckTestSuite() throws IOException {

	//Here we can add some more Logic for reading data from Excel file and performing the test case.
	// ALong with some more logic to add test result into the Excel file.
	//I have skip that part for now

	}

}
