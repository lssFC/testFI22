package com.fc.client.ParentClass;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

//1. Define and initialize two properties file
//2. Object of WebDriver 
//3. Launch Browser
//4. Define Timeout
//5. Maximize Browser Window
//6. Define Logs

public class BaseInit {

	public static WebDriver driver = null;
	public static Properties sitedata = null;
	public static Properties storage = null;
	public static Logger log = null;
	
	
	public void StartUp() throws IOException {

		if (driver == null) {
					
			log = Logger.getLogger(BaseInit.class);
			 String log4jConfigFile = System.getProperty("user.dir")
		                 + "\\"+"log4j.properties";
			PropertyConfigurator.configure(log4jConfigFile);
			// Upon un-commenting BasicConfigurator will show logs in console
			//BasicConfigurator.configure(); 
			log.setLevel(Level.ALL);
			log.info("Logger is configured successfully...");
			log.info("LOADING Properties file......");
			sitedata = new Properties();
			FileInputStream fi = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\com\\fc\\client\\PropertiesData\\SiteData.properties");
			String UserDir = "C:\\Users\\User\\workspace\\Friendsurance";
			sitedata.load(fi);

			storage = new Properties();	
			fi = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\com\\fc\\client\\PropertiesData\\ObjectStorage.properties");
			//We can either use object storage XPATH or I have created one Constants file to get the XPATH
			storage.load(fi);

			if (sitedata.getProperty("browser").equalsIgnoreCase("firefox")) {
				System.setProperty("webdriver.gecho.driver",
						UserDir+"\\libs\\geckodriver.exe");
				driver = new FirefoxDriver();
			} else if (sitedata.getProperty("browser").equalsIgnoreCase("chrome")) {

				System.setProperty("webdriver.chrome.driver",
						UserDir+"\\libs\\chromedriver.exe");
				driver = new ChromeDriver();
			} else if (sitedata.getProperty("browser").equalsIgnoreCase("ie")) {

				System.setProperty("webdriver.ie.driver",
						UserDir+"\\libs\\IEDriverServer.exe");

				driver = new InternetExplorerDriver();
			}
			log.info("Driver files are configured successfully...");
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			log.info(driver+" - Browser is set successfully...");
		}
	}

	public static WebElement verifyXpath(String xpathVar) {

		try {

			return driver.findElement(By.xpath(storage.getProperty(xpathVar)));

		} catch (Throwable t) {

			System.out.println("Xpath Not Found");
			return null;
		}

	}

}
