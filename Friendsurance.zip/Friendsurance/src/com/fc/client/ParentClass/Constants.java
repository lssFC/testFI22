package com.fc.client.ParentClass;

import org.openqa.selenium.By;

public class Constants {

	//Default credentials
	public static String USERNAME = "FITUser0001";
	public static String RegisterUSERNAME = "FITUser0005";
	public static String RegisterSameUSERNAME = "FITUser0006";
	public static String PASSWORD = "test1234";
	public static String DefaultCategory = "TestingUserCategory";
	public static String BaseURL = "http://thawing-shelf-73260.herokuapp.com";

	// Alert
	public static final By Login_alertMessage = By.cssSelector("div.alert.alert-danger");
	
	//Header
	public static final By Header_LoginPage = By.tagName("h3");
	public static final By Header_ListExpenses = By.tagName("h1");
	public static final By Header_ListCategory = By.tagName("h1");
	public static final By Header_AddCategory = By.tagName("h1");
	public static final By Header_AddExpenses = By.tagName("h1");
	public static final By Link_RegisterNewUser = By.linkText("Register new user");
	public static final By Header_RegistrationPage = By.tagName("h3");

	// Login /Account Page
	public static final By Txt_Username = By.id("login");
	public static final By Txt_Password = By.id("password");
	public static final By Txt_AddPassword = By.id("password1");
	public static final By Txt_RepeatPassword = By.id("password2");
	public static final By Btn_Submit = By.id("submit");
	public static final By Link_logout = By.id("logout");
	public static final By Link_editaccount = By.id("editaccount");
	
	// Add Expenses Page
	public static final By Link_AddExpenses = By.id("go_add_expense");
	public static final By Txt_Day = By.id("day");
	public static final By Txt_Month = By.id("month");
	public static final By Txt_Year = By.id("year");
	public static final By Txt_ExpenseName = By.id("name");
	public static final By Txt_AddAmount = By.id("amount");
	public static final By Txt_AddReason = By.id("reason");

	// Add Category Page
	public static final By Link_ListCategory = By.id("go_list_categories");
	public static final By Btn_AddCategory = By.cssSelector("img[alt=\"add category\"]");
	public static final By Txt_CategoryName = By.id("name");
	public static final By DropDown_Category = By.id("category");
	
	
	
	

}
