package com.fc.client.Utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.fc.client.ParentClass.BaseInit;
import com.fc.client.ParentClass.Constants;

public class Util extends BaseInit {
	public static File file_ScreenShot;
	public static WebDriverWait wait;

	public static String destFile = System.getProperty("user.home") + "\\Errors\\ScreenShots";
	/**
	 *  Method - Method to perform Registration
	 *	Values - String Username
	 */
	public static void Registration(String Username) {
		driver.get(Constants.BaseURL + "/index.jsp");

		ClickElementBy(driver, Constants.Link_RegisterNewUser);

		String header = GetTextBy(driver, Constants.Header_RegistrationPage);
		Assert.assertEquals("Register new user", header, "Error: Unable to navigate to Registration page..");

		Element_EnterText(Constants.Txt_Username, Username);
		Element_EnterText(Constants.Txt_AddPassword, Constants.PASSWORD);
		Element_EnterText(Constants.Txt_RepeatPassword, Constants.PASSWORD);
		ClickElementBy(driver, Constants.Btn_Submit);

		if (Util.isElementExistsBy(driver, Constants.Login_alertMessage)) {
			String alertMessage = Util.GetTextBy(driver, Constants.Login_alertMessage);
			Assert.assertEquals("unknown login or wrong password", alertMessage, "Error: Invalid alert message..");
		}
	}
	
	/**
	 *  Method - Method to perform Login
	 *	Values - String Username/password
	 */
	public static void login(String Username, String password) {
		driver.get("http://thawing-shelf-73260.herokuapp.com/index.jsp");
		String header = GetTextBy(driver, Constants.Header_RegistrationPage);
		Assert.assertEquals("Login", header, "Error: Unable to navigate to Login page..");
		Element_EnterText(Constants.Txt_Username, Username);
		Element_EnterText(Constants.Txt_Password, password);
		ClickElementBy(driver, Constants.Btn_Submit);
		System.out.println("Login successgully with username:"+Username);
	}
	
	/**  Method - Method to perform Logout
	 */
	public static void logout() {
		Util.ClickElementBy(driver, Constants.Link_logout);

	}
	
	/***  Method - Method to Check Category on table
	 *	Values - String Category
	 */
	public static boolean CheckCategoryPresent(String exp_FirstCategory) throws InterruptedException {
		
		Thread.sleep(5000);
		driver.navigate().refresh();
		Thread.sleep(5000);
		
		boolean bFlag = false;
		WebElement wb_table = driver.findElement(By.className("table"));
		List<WebElement> List_parent_CategoryName = wb_table.findElements(By.tagName("tr"));

		for (WebElement categoryName : List_parent_CategoryName) {
			List<WebElement> List_Child_CategoryName = categoryName.findElements(By.tagName("td"));
			for (WebElement category_Name : List_Child_CategoryName) {

				String Actual_categoryName = category_Name.getText();
				if (Actual_categoryName.equalsIgnoreCase(exp_FirstCategory)) {
					Assert.assertEquals(Actual_categoryName, exp_FirstCategory, "Error: Category name is different..");
					bFlag = true;
					System.out.println("Category is present on list:"+exp_FirstCategory);
					break;
				}
							}
		}
				return bFlag;
	}
	
	/**
	 *  Method - Method to Remove Category
	 *	Values - String Category
	 */
	public static void RemoveCategory(String exp_FirstCategory) {

		WebElement wb_table = driver.findElement(By.className("table"));
		List<WebElement> List_parent_CategoryName = wb_table.findElements(By.tagName("tr"));
		boolean bFlag = false;
		boolean deleteFlag = false;

		for (WebElement categoryName : List_parent_CategoryName) {
			List<WebElement> List_Child_CategoryName = categoryName.findElements(By.tagName("td"));
			System.out.println(List_Child_CategoryName.size() + "  - List_Child_CategoryName.");
			for (WebElement category_Name : List_Child_CategoryName) {

				String Actual_categoryName = category_Name.getText();
				if (Actual_categoryName.equalsIgnoreCase(exp_FirstCategory)) {
					System.out.println(Actual_categoryName + "  - Category is created successfully...");
					Assert.assertEquals(Actual_categoryName, exp_FirstCategory, "Error: Category name is different..");
					bFlag = true;

					if (bFlag) {
						WebElement CheckDeleteButton = List_Child_CategoryName.get(1);
						List<WebElement> List_Delete_Button = CheckDeleteButton.findElements(By.tagName("a"));
						WebElement wb_DeleteButton = List_Delete_Button.get(1);
						wb_DeleteButton.click();
						deleteFlag = true;
						break;
					}
				}
				break;
			}
		}
	}
	
	/**
	 *  Method - Method to Create Category
	 *	Values - String Category
	 */
	public static void CreateCategory(String CategoryName) {

		ClickElementBy(driver, Constants.Link_ListCategory);
		ClickElementBy(driver, Constants.Btn_AddCategory);
		Element_EnterText(Constants.Txt_CategoryName, CategoryName);
		ClickElementBy(driver, Constants.Btn_Submit);
		System.out.println("Category created on list:"+CategoryName);
	}
	
	
	/**
	 *  Method - Method to Add expenses
	 *	Values - String Day/month/year/Category/amount/Reason 
	 */	
	public static void AddExpense(String Day, String Month, String Year, String Category, String Amount,
			String Reason) {

		ClickElementBy(driver, Constants.Link_AddExpenses);
		String header = GetTextBy(driver, Constants.Header_AddExpenses);
		Assert.assertEquals("Add Expense", header, "Error: Unable to navigate to Add Expenses page..");

		Element_EnterText(Constants.Txt_Day, Day);
		Element_EnterText(Constants.Txt_Month, Month);
		Element_EnterText(Constants.Txt_Year, Year);
		Element_EnterText(Constants.Txt_AddAmount, Amount);
		Element_EnterText(Constants.Txt_AddReason, Reason);

		new Select(driver.findElement(Constants.DropDown_Category)).selectByVisibleText(Constants.DefaultCategory);

		ClickElementBy(driver, Constants.Btn_Submit);
		System.out.println("New expense is added..");
	}
	
	/**
	 *  Method - Method to verify XPTH from Storage filr
	 *	Return Type and Value - String XPATH 
	 */
	public static WebElement verifyXpath(String xpathVar) {

		try {
			return driver.findElement(By.xpath(storage.getProperty(xpathVar)));
		} catch (Throwable t) {
			System.out.println("Xpath Not Found");
			return null;
		}
	}

	/**
	 *  Method - Method to Enter text if element exist
	 *	Return Type and Value - String and By WebELement (returns string)
	 */
	public static void Element_EnterText(By xpathVar, String EnterValue) {

		WebDriverWait wait = new WebDriverWait(driver, 5000);
		try {
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(xpathVar)));
			driver.findElement(xpathVar).clear();
			driver.findElement(xpathVar).sendKeys(EnterValue);
		} catch (Exception e) {
			System.out.println(xpathVar + "Web element Not Found..." + e);
		}

	}
	
	/**
	 *  Method - Method to Get text if element exist
	 *	Return Type and Value - Driver and By WebELement (returns string)
	 */
	public static String GetTextBy(WebDriver driver, By element) {
		String TextVal = null;
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		try {
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(element)));
			TextVal = driver.findElement(element).getText();
		} catch (Exception e) {
			System.out.println(element + "Web element Not Found..." + e);
		}
		return TextVal;
	}
	
	/**
	 *  Method - Method to Click if element exist
	 *	Return Type and Value - Driver and By WebELement 
	 */
	public static void ClickElementBy(WebDriver driver, By element) {

		WebDriverWait wait = new WebDriverWait(driver, 5000);
		try {
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(element)));
			driver.findElement(element).click();
		} catch (Exception e) {
			System.out.println(element + "Web element Not Found..." + e);
		}

	}
	
	/**
	 *  Method - Method to Check if element exist
	 *	Return Type and Value - Driver and WebELement (returns Boolean)
	 */
	public static boolean isElementExists(WebDriver driver, WebElement element) {
	
		boolean bFlag = false;
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			if (element.isDisplayed())
				bFlag = true;
		} catch (Exception e) {
			bFlag = false;
		}
		return bFlag;
	}
	
	/**
	 *  Method - Method to Check if element exist
	 *	Return Type and Value - Driver and BY (returns Boolean)
	 */
	public static boolean isElementExistsBy(WebDriver driver, By element) {
		
		boolean bFlag = false;
		WebDriverWait wait = new WebDriverWait(driver, 5000);
		try {
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(element)));
			if (driver.findElement(element).isDisplayed())
				bFlag = true;
		} catch (Exception e) {
			bFlag = false;
		}
		return bFlag;
	}
	
	
	/**
	 *  Method - Take screenshot
	 *	**/
	public static void takeScreenShot(WebDriver driver, String str_StoryName, String str_ScreenShotName)
			throws Exception {
		file_ScreenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(file_ScreenShot,
					new File(destFile + "\\" + str_StoryName + "_" + str_ScreenShotName + ".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Thread.sleep(1000);
	}

	/**
	 *  Method - Method to get current date and time
	 *	Return Type and Value - String (returns date and time)
	 */
	public static String GetCurrentDateTime()
	{
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String dateNow = formatter.format(currentDate.getTime());
		return dateNow;    	
	}
	
	/**
	 * This method is used to generate the random number which will be used while saving a screenshot
	 * Return type is Integer
	 */
	public static int GetRandomNumber()
	{
		Random rand = new Random();
		int numNoRange = rand.nextInt();
		//System.out.println("Generated Random Number without specifying any range is : " + numNoRange);
		return numNoRange;
	}
}
